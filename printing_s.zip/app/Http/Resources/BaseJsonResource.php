<?php


namespace App\Http\Resources;


use App\Domain\_core\APIItems;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BaseJsonResource extends JsonResource implements APIItems
{

}
