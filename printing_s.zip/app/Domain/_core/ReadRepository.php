<?php


namespace App\Domain\_core;


abstract class ReadRepository
{

}
