<?php


namespace App\Domain\_core\Meta;


/**
 * Class Meta
 * @package App\Domain\_core\Meta
 *
 * @author Enver Menadjiev <enver1323@gmail.com>
 *
 * @property
 */
class Meta
{
    public $description;
    public $keywords;
}
