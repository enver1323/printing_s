<?php


namespace App\Domain\_core;


abstract class Service
{

}
