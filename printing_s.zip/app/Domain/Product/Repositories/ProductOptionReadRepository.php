<?php


namespace App\Domain\Product\Repositories;



use App\Domain\_core\ReadRepository;

class ProductOptionReadRepository extends ReadRepository
{

}
