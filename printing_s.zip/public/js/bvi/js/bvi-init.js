jQuery(document).ready(function($){
    $.bvi();
});