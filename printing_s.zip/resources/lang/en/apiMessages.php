<?php

return [
    'success' => 'Success'
];
