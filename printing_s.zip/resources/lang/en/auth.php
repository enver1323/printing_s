<?php

return [
    'failed' => 'These credentials do not match our records.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
    'You need to confirm' => 'You need to confirm your account. Please check your email.',
    'login' => 'Login',
    'register' => 'Register',
    'sign_in' => 'Sign In',
    'sign_out' => 'Sign Out',
    'sign_up' => 'Sign Up',
];
