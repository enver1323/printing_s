<?php
return [
    'welcome' => 'Welcome.',
    'language' => 'Language',
    'russian' => 'Russian',
    'english' => 'English',
];
