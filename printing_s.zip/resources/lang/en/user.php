<?php

return [
    'deleted_successfully' => 'User deleted successfully',
    'verified_successfully' => 'User verified successfully',
];
