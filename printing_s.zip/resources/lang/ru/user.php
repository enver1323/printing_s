<?php

return [
    'deleted_successfully' => 'Пользователь успешно удален.',
    'verified_successfully' => 'Пользователь успешно активирован.',
];
