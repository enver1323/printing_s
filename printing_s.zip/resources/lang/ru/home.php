<?php
return [
    'welcome' => 'Добро пожаловать.',
    'language' => 'Язык',
    'russian' => 'Русский',
    'english' => 'Английский',
];
