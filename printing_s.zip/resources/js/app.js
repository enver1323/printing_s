window.$ = window.jQuery = require('jquery');
require('bootstrap');
window.bsCustomFileInput = require('mdbootstrap/js/modules/bs-custom-file-input');
require('mdbootstrap');
