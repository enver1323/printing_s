document.addEventListener('DOMContentLoaded', function () {
    const owl = require('owl.carousel');
});



