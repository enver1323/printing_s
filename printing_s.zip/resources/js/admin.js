try {
    window.$ = window.jQuery = require('jquery');
} catch (e) {
}
require('startbootstrap-sb-admin-2/vendor/bootstrap/js/bootstrap.bundle.min.js');
require('startbootstrap-sb-admin-2/vendor/jquery-easing/jquery.easing.min.js');
require('startbootstrap-sb-admin-2/js/sb-admin-2.js');
require('startbootstrap-sb-admin-2/vendor/chart.js/Chart.min.js');
import 'jquery-ui/ui/widgets/datepicker.js';
import 'fontawesome-iconpicker/dist/js/fontawesome-iconpicker.min.js'
